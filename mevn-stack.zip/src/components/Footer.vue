<template>
    <footer id="custom-footer">
        <span class="mr-4">&copy; 2019 Web Cretin</span>
        <span class="mr-4">Privacy</span>
        <span>Terms of Service</span>
    </footer>
</template>